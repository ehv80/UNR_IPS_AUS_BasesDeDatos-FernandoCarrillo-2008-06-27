/* Setting the s_account */
function s_setAccount(){
var s_account="";

var curUrl = location.href;
	
		if(curUrl.indexOf("-stage") != -1 ) {
				s_account = "oracledevall,oracledevotn1";
		}
		else {
				s_account = "oracleglobal,oracleotnlive";
		}
		
		return s_account;
	}